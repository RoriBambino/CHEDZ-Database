--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE chedz;
--
-- Name: chedz; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE chedz WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE chedz OWNER TO postgres;

\connect chedz

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acknowledgement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acknowledgement (
    ac_id integer NOT NULL,
    ac_receipt bytea NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acknowledgement OWNER TO postgres;

--
-- Name: delivered_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivered_item (
    di_id integer NOT NULL,
    di_quantity integer NOT NULL,
    di_expiry date,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    dlr_id integer NOT NULL,
    item_id integer NOT NULL
);


ALTER TABLE public.delivered_item OWNER TO postgres;

--
-- Name: delivery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery (
    dlr_id integer NOT NULL,
    po_id integer NOT NULL,
    dlr_status character varying(10) DEFAULT 'Pending'::character varying,
    dlr_receipt bytea NOT NULL,
    dlr_receiving_memo bytea NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.delivery OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    emp_id integer NOT NULL,
    emp_fname character varying(20) NOT NULL,
    emp_mname character varying(15) NOT NULL,
    emp_lname character varying(15) NOT NULL,
    emp_email character varying(50) NOT NULL,
    emp_password character varying(50) NOT NULL,
    emp_status character varying(50) DEFAULT 'Active'::character varying,
    emp_type character varying(50) DEFAULT 'EMP'::character varying,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item (
    item_id integer NOT NULL,
    item_name character varying(50) NOT NULL,
    item_type character varying(15) NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    unit_id integer NOT NULL
);


ALTER TABLE public.item OWNER TO postgres;

--
-- Name: purchasing_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchasing_order (
    po_id integer NOT NULL,
    rq_id integer NOT NULL,
    po_status character varying(50) DEFAULT 'Pending'::character varying,
    po_approved_by integer,
    po_quotation bytea NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP,
    vnd_id integer
);


ALTER TABLE public.purchasing_order OWNER TO postgres;

--
-- Name: req_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.req_item (
    ri_id integer NOT NULL,
    rq_id integer NOT NULL,
    item_id integer NOT NULL,
    ac_id integer NOT NULL,
    ri_quantity integer NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.req_item OWNER TO postgres;

--
-- Name: req_job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.req_job (
    rj_id integer NOT NULL,
    rq_id integer NOT NULL,
    rj_desc character varying(50) NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.req_job OWNER TO postgres;

--
-- Name: request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.request (
    rq_id integer NOT NULL,
    rq_type character varying(20) NOT NULL,
    rq_desc character varying(50) NOT NULL,
    rq_status character varying(20) DEFAULT 'Pending'::character varying,
    rq_approved_by integer,
    emp_id integer NOT NULL,
    date_created date DEFAULT CURRENT_TIMESTAMP,
    date_updated date DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.request OWNER TO postgres;

--
-- Name: unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.unit (
    unit_id integer NOT NULL,
    unit_name character varying(50) NOT NULL
);


ALTER TABLE public.unit OWNER TO postgres;

--
-- Name: vendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vendor (
    vnd_id integer NOT NULL,
    vnd_name character varying(50) NOT NULL,
    vnd_contact integer NOT NULL,
    vnd_email character varying(60) NOT NULL
);


ALTER TABLE public.vendor OWNER TO postgres;

--
-- Data for Name: acknowledgement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acknowledgement (ac_id, ac_receipt, date_created, date_updated) FROM stdin;
\.
COPY public.acknowledgement (ac_id, ac_receipt, date_created, date_updated) FROM '$$PATH$$/4879.dat';

--
-- Data for Name: delivered_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivered_item (di_id, di_quantity, di_expiry, date_created, date_updated, dlr_id, item_id) FROM stdin;
\.
COPY public.delivered_item (di_id, di_quantity, di_expiry, date_created, date_updated, dlr_id, item_id) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: delivery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery (dlr_id, po_id, dlr_status, dlr_receipt, dlr_receiving_memo, date_created, date_updated) FROM stdin;
\.
COPY public.delivery (dlr_id, po_id, dlr_status, dlr_receipt, dlr_receiving_memo, date_created, date_updated) FROM '$$PATH$$/4878.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (emp_id, emp_fname, emp_mname, emp_lname, emp_email, emp_password, emp_status, emp_type, date_created, date_updated) FROM stdin;
\.
COPY public.employee (emp_id, emp_fname, emp_mname, emp_lname, emp_email, emp_password, emp_status, emp_type, date_created, date_updated) FROM '$$PATH$$/4873.dat';

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item (item_id, item_name, item_type, date_created, date_updated, unit_id) FROM stdin;
\.
COPY public.item (item_id, item_name, item_type, date_created, date_updated, unit_id) FROM '$$PATH$$/4881.dat';

--
-- Data for Name: purchasing_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchasing_order (po_id, rq_id, po_status, po_approved_by, po_quotation, date_created, date_updated, vnd_id) FROM stdin;
\.
COPY public.purchasing_order (po_id, rq_id, po_status, po_approved_by, po_quotation, date_created, date_updated, vnd_id) FROM '$$PATH$$/4876.dat';

--
-- Data for Name: req_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.req_item (ri_id, rq_id, item_id, ac_id, ri_quantity, date_created, date_updated) FROM stdin;
\.
COPY public.req_item (ri_id, rq_id, item_id, ac_id, ri_quantity, date_created, date_updated) FROM '$$PATH$$/4882.dat';

--
-- Data for Name: req_job; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.req_job (rj_id, rq_id, rj_desc, date_created, date_updated) FROM stdin;
\.
COPY public.req_job (rj_id, rq_id, rj_desc, date_created, date_updated) FROM '$$PATH$$/4875.dat';

--
-- Data for Name: request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.request (rq_id, rq_type, rq_desc, rq_status, rq_approved_by, emp_id, date_created, date_updated) FROM stdin;
\.
COPY public.request (rq_id, rq_type, rq_desc, rq_status, rq_approved_by, emp_id, date_created, date_updated) FROM '$$PATH$$/4874.dat';

--
-- Data for Name: unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.unit (unit_id, unit_name) FROM stdin;
\.
COPY public.unit (unit_id, unit_name) FROM '$$PATH$$/4880.dat';

--
-- Data for Name: vendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vendor (vnd_id, vnd_name, vnd_contact, vnd_email) FROM stdin;
\.
COPY public.vendor (vnd_id, vnd_name, vnd_contact, vnd_email) FROM '$$PATH$$/4877.dat';

--
-- Name: acknowledgement acknowledgement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acknowledgement
    ADD CONSTRAINT acknowledgement_pkey PRIMARY KEY (ac_id);


--
-- Name: delivered_item delivered_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivered_item
    ADD CONSTRAINT delivered_item_pkey PRIMARY KEY (di_id);


--
-- Name: delivery delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_pkey PRIMARY KEY (dlr_id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (emp_id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (item_id);


--
-- Name: purchasing_order purchasing_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchasing_order
    ADD CONSTRAINT purchasing_order_pkey PRIMARY KEY (po_id);


--
-- Name: req_item req_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.req_item
    ADD CONSTRAINT req_item_pkey PRIMARY KEY (ri_id);


--
-- Name: req_job req_job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.req_job
    ADD CONSTRAINT req_job_pkey PRIMARY KEY (rj_id);


--
-- Name: request request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_pkey PRIMARY KEY (rq_id);


--
-- Name: unit unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (unit_id);


--
-- Name: vendor vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vendor
    ADD CONSTRAINT vendor_pkey PRIMARY KEY (vnd_id);


--
-- Name: delivered_item delivered_item_dlr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivered_item
    ADD CONSTRAINT delivered_item_dlr_id_fkey FOREIGN KEY (dlr_id) REFERENCES public.delivery(dlr_id) ON UPDATE CASCADE;


--
-- Name: delivered_item delivered_item_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivered_item
    ADD CONSTRAINT delivered_item_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE CASCADE;


--
-- Name: delivery delivery_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchasing_order(po_id) ON UPDATE CASCADE;


--
-- Name: item item_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.unit(unit_id) ON UPDATE CASCADE;


--
-- Name: purchasing_order purchasing_order_rq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchasing_order
    ADD CONSTRAINT purchasing_order_rq_id_fkey FOREIGN KEY (rq_id) REFERENCES public.request(rq_id) ON UPDATE CASCADE;


--
-- Name: purchasing_order purchasing_order_rq_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchasing_order
    ADD CONSTRAINT purchasing_order_rq_id_fkey1 FOREIGN KEY (rq_id) REFERENCES public.request(rq_id) ON UPDATE CASCADE;


--
-- Name: purchasing_order purchasing_order_vnd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchasing_order
    ADD CONSTRAINT purchasing_order_vnd_id_fkey FOREIGN KEY (vnd_id) REFERENCES public.vendor(vnd_id) ON UPDATE CASCADE;


--
-- Name: req_item req_item_ac_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.req_item
    ADD CONSTRAINT req_item_ac_id_fkey FOREIGN KEY (ac_id) REFERENCES public.acknowledgement(ac_id) ON UPDATE CASCADE;


--
-- Name: req_item req_item_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.req_item
    ADD CONSTRAINT req_item_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.item(item_id) ON UPDATE CASCADE;


--
-- Name: req_item req_item_rq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.req_item
    ADD CONSTRAINT req_item_rq_id_fkey FOREIGN KEY (rq_id) REFERENCES public.request(rq_id) ON UPDATE CASCADE;


--
-- Name: req_job req_job_rq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.req_job
    ADD CONSTRAINT req_job_rq_id_fkey FOREIGN KEY (rq_id) REFERENCES public.request(rq_id) ON UPDATE CASCADE;


--
-- Name: request request_emp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_emp_id_fkey FOREIGN KEY (emp_id) REFERENCES public.employee(emp_id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

